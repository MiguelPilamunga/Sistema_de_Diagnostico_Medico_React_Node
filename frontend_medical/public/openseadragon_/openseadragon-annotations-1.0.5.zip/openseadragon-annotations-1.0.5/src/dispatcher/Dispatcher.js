import { Dispatcher as FluxDispatcher } from 'flux';

const Dispatcher = new FluxDispatcher();

export default Dispatcher;
